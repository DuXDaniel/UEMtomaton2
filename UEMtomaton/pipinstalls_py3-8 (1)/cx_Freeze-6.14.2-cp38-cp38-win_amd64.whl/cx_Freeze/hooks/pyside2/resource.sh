#!/bin/bash

pyside2-rcc -o resource.py resource.qrc
